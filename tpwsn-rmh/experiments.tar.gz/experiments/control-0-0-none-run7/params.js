var runNumber = 7;
var maxFailureCount = 0;
var failureMode = "none";
var moteRecoveryDelay = 0;
var moteFailureProbability = 200;
var simulationStopTick = 0;