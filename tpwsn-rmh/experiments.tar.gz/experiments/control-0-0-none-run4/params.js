var runNumber = 4;
var maxFailureCount = 0;
var failureMode = "none";
var moteRecoveryDelay = 0;
var moteFailureProbability = 200;
var simulationStopTick = 0;